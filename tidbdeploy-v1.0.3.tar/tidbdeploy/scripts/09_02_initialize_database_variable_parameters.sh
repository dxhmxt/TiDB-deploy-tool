
#!/bin/bash
##########################
#Script name:  09_02_initialize_database_variable_parameters.sh
#Script description: initialize database variable parameters script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
set -e 
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_09_02_initialize_database_variable_parameters.log"


cpoy_conf_script_file(){
echo "cpoy conf script file to  $dirHome."

cp -f  $confPath/cluster_plan.conf $dirHome/mirror
cp -f  $confPath/cluster_base_info.conf $dirHome/mirror

cp -f  $scriptsPath/09_02_01_cluster_instance_user_initialize_database_variable_parameters.sh $dirHome/mirror
cp -f  $confPath/tidbinitvar.txt $dirHome/mirror
}

chown_conf_script_file_auth()
{
echo "chown conf and script file instance user grant."
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/cluster_plan.conf
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/cluster_base_info.conf
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/09_02_01_cluster_instance_user_initialize_database_variable_parameters.sh
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/tidbinitvar.txt 
}


initialize_database_variable_parameters()
{
echo "initialize database variable parameters."
su - $tidbInstanceUser -c "sh $dirHome/mirror/09_02_01_cluster_instance_user_initialize_database_variable_parameters.sh"
}

root_initialize_database_variable_parameters()
{
cpoy_conf_script_file
chown_conf_script_file_auth
initialize_database_variable_parameters
}


root_initialize_database_variable_parameters |tee  ${scriptsLog}
