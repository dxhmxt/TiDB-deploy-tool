
#!/bin/bash
##########################
#Script name:  06_02_01_tidb_deploy_cluster_user.sh
#Script description: tidb deploy script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
set -e

source ./mirror/cluster_base_info.conf


serverDir=tidb-$communityOrEnterpriseVersion-server-$version-linux-$arch
toolkitDir=tidb-$communityOrEnterpriseVersion-toolkit-$version-linux-$arch

yamlFile=$dirHome/mirror/topology.yaml


arch_check(){
echo "##os and install package arch check."
case $(uname -m) in
    amd64|x86_64) osarch=amd64 ;;
    arm64|aarch64) osarch=arm64 ;;
    *) osarch= ;;
esac


if [ $osarch != $arch ];then 
    echo "this tidb install package arch is $arch,os arch is $osarch,please reload down $osarch tidb install package."
    exit 1
else 
    echo "os $osarch and install package $arch check ok."
fi  
}




install_tiup()
{
echo "##install tiup"
sh $dirHome/mirror/$serverDir/local_install.sh 
source $dirHome/.bash_profile 
tiup mirror show 
echo "tiup install done."
}

merge_mirror()
{
echo "##tidb install package merge mirror."
cp -r $dirHome/mirror/$serverDir/keys $dirHome/.tiup 
tiup mirror merge $dirHome/mirror/$toolkitDir
echo "tidb install package merge mirror is done."
}



tidb_install()
{
echo "##instal tidb cluster."
tiup cluster check $yamlFile --user $tidbInstanceUser
tiup cluster deploy $clusterName -c $concurrencyInt  $version  $yamlFile   --user $tidbInstanceUser -y
tiup cluster start $clusterName
tiup cluster display $clusterName
}




main()
{
arch_check
install_tiup
merge_mirror
tidb_install
}

main 
