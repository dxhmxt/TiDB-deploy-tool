
#!/bin/bash
##########################
#Script name:  01_01_set_root_ssh_mutual_trust.sh 
#Script description: set root huxin script
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

osUserRoot=root
osUserRootPasswd=$1

echo $osUserRootPasswd

confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
echo "ssh port is $sshPort."
echo $osUserRootPasswd

logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_01_01_set_root_ssh_mutual_trust.log"

#cat   $confPath/cluster_plan.conf |awk -F" " '{print $1}' |sort -u > $confPath/iplist.txt


create_rsa()
{
ssh-keygen -t rsa -P '' -f ~/.ssh/id_rsa
}


set_root_mutual_trust()
{
echo "set root huxin."
sed -i '{'/^$/d';'/^#/d'}'   $confPath/iplist.txt

for line in `cat $confPath/iplist.txt`
do

echo  "$line set huxin."
expect -c " 
  spawn ssh-copy-id -p $sshPort -o StrictHostKeyChecking=no $osUserRoot@$line
  expect \"password:\" 
  send \"${osUserRootPasswd}\r\"
  expect eof
  "
done
}


check_root_mutual_trust()
{
echo "check root huxin."
for line in `cat $confPath/iplist.txt`

do
ssh $osUserRoot@$line "hostname -I;date"
if [ $? -eq 0 ];then 
   echo "$line ssh mutual trust is ok."
else 
   echo "$line ssh mutual trust is not ok."
fi  
done

}

set_root_ssh_mutual_trust()
{
create_rsa
set_root_mutual_trust
#check_root_mutual_trust
}

set_root_ssh_mutual_trust | tee  ${scriptsLog}

