
##########################
#Script name:  05_06_01_create_newyamlfile_from_yamlfile.sh
#Script description: create newyamlfile from yamlfile script
#Created Date:2022/11/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_05_06_01_create_newyamlfile_from_yamlfile.log"



yamlFile=$confPath/topology.yaml
aAndBIpListFile=$confPath/a_and_b_iplist.txt

sed -i '{'/^$/d';'/^#/d'}'  $aAndBIpListFile 

create_newyamlfile_from_yamlfile()
{
echo "backup $yamlFile to $yamlFile.$nowTime."
cp $yamlFile $yamlFile.$nowTime 

while read line
do
w=`echo $line  |awk '{print $1}'`
f=`echo $line  |awk '{print $2}'`
sed -i "s/${w}/${f}/g"   $yamlFile
done < $aAndBIpListFile
}

main()
{
create_newyamlfile_from_yamlfile 
echo "please check new yaml file $yamlFile, and check old yaml file $yamlFile.$nowTime."

echo "#######this is new yaml file $yamlFile."
cat  $yamlFile 

echo "####################################################################################"
echo " " 
echo "####################################################################################"

echo "#######this is old yaml file $yamlFile.$nowTime."

cat  $yamlFile.$nowTime
}

main |tee   ${scriptsLog}
