
#!/bin/bash
##########################
#Script name: 02_loop_set_os_optimal_parameters.sh 
#Script description: loop set os optimal parameters script
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
set  -e


confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
logPath="/root/tidbdeploy/log"
scriptsLog="$logPath/${nowTime}_02_loop_set_os_optimal_parameters.log"

instanceUserInfo=`cat $confPath/cluster_base_info.conf|grep  tidbInstanceUser  |head -n1`


echo "##cluster instance user is  $tidbInstanceUser."
echo "initialize script variable,add instance user is $tidbInstanceUser."

sed  -i "/nowTime/a $instanceUserInfo" 02_01_set_os_optimal_parameters.sh 



loop_set_os_optimal_parameters(){
for line in `cat $confPath/iplist.txt`
do
  echo  "###set $line optimal parameters.###"
  ssh -Tq -p $sshPort root@$line <02_01_set_os_optimal_parameters.sh
done

echo "$nowTime cluster all ip  set  os optimal  parameters is done. "
}

loop_set_os_optimal_parameters |tee  ${scriptsLog} 

sed -i "/^tidbInstanceUser/d" 02_01_set_os_optimal_parameters.sh
