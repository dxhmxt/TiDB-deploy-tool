
#!/bin/bash
##########################
#Script name: 09_initialize_database_variable_parameters_menu.sh 
#Script description: initialize database variable parameters menu script 
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao 
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
logPath="/root/tidbdeploy/log"
scriptsLog="$logPath/${nowTime}_09_initialize_database_variable_parameters_menu.log"
initialize_database_variable_parameters_menu()
{
while [ 1=1 ]
do
clear
echo "|—————————————————————————————————————————————————|"
echo "|          9.初始化数据库变量参数                 |"
echo "|—————————————————————————————————————————————————|"
echo "|          9.1 编辑数据库变量参数文件             |"
echo "|          9.2 初始化数据库变量参数               |"
echo "|—————————————————————————————————————————————————|"
echo "|          99.退出                                |"
echo "|          请输入选项：                           |"
echo "|_________________________________________________|"
read option
  case $option in
  9.1)
    clear
    echo ""
    echo '                编辑数据库变量参数文件 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
                echo "编辑数据库变量参数文件tidbinitvar.txt"
        vim  $confPath/tidbinitvar.txt
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

  9.2)
    clear
    echo ""
    echo '                       初始化数据库变量参数  [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        sh  $scriptsPath/09_02_initialize_database_variable_parameters.sh 
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

 

  99)
    stty intr ^C
    break
    ;;
  *)
    if [ "$option" == "" ];then
      echo ""
    else
      echo ""
      echo "                     选项输入错误！"
      sleep 1
    fi
                                esac  
done    

}



initialize_database_variable_parameters_menu |tee ${scriptsLog}
