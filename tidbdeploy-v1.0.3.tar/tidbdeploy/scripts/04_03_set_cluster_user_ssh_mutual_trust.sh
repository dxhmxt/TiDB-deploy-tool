#!/bin/bash
##########################
#Script name:  04_03_set_cluster_user_ssh_mutual_trust.sh
#Script description: set cluster instance user ssh mutual trust script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_04_03_set_cluster_user_ssh_mutual_trust.log"
#dirHome=`su - $tidbInstanceUser -c "pwd"`



cpoy_conf_script_file(){
cp -f  $confPath/cluster_base_info.conf $dirHome  
cp -f  $scriptsPath/04_03_01_loop_set_cluster_user_ssh_mutual_trust.sh $dirHome
cp -f  $confPath/iplist.txt $dirHome
}

chown_conf_script_file_auth()
{
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/cluster_base_info.conf
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/04_03_01_loop_set_cluster_user_ssh_mutual_trust.sh
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/iplist.txt 
}

set_instance_trust()
{
echo "set instance user huxin."
su - $tidbInstanceUser -c "sh 04_03_01_loop_set_cluster_user_ssh_mutual_trust.sh"
}

set_cluster_user_ssh_mutual_trust()
{
cpoy_conf_script_file
chown_conf_script_file_auth
set_instance_trust
}

set_cluster_user_ssh_mutual_trust |tee  ${scriptsLog}
