

#!/bin/bash
##########################
#Script name: 01_set_root_ssh_mutual_trust_text_menu.sh 
#Script description: os system root ssh set script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao 
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
stty intr ^C
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
logPath="/root/tidbdeploy/log"
scriptsLog="$logPath/${nowTime}_01_set_root_ssh_mutual_trust_text_menu.log"
set_root_mutual_trust_child_meun()
{
while [ 1=1 ]
do
clear
echo "|—————————————————————————————————————————————————|"
echo "|            2.设置root互信                       |"
echo "|—————————————————————————————————————————————————|"
echo "|          2.1 设置系统root用户互信               |"
echo "|          2.2 检查系统root用户互信               |"
echo "|—————————————————————————————————————————————————|"
echo "|          99.退出                                |"
echo "|          请输入选项：                           |"
echo "|_________________________________________________|"
read option
  case $option in


  2.1)
    clear
    echo ""
    echo '                       设置系统root用户互信  [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        echo "                     请输入root用户密码: "
        read rootpasswd;
        sh  $scriptsPath/01_01_set_root_ssh_mutual_trust.sh  $rootpasswd
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

  2.2)
    clear
    echo ""
    echo '                       检查系统root用户互信 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        sh  $scriptsPath/01_01_check_root_ssh_mutual_trust.sh
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;



  99)
    stty intr ^C
    break
    ;;
  *)
    if [ "$option" == "" ];then
      echo ""
    else
      echo ""
      echo "                     选项输入错误！"
      sleep 1
    fi
                                esac  
done    

}



set_root_mutual_trust_child_meun |tee ${scriptsLog}


