#!/bin/bash
##########################
#Script name: 03_mount_data_disk_text_menu.sh
#Script description: os mount data disk text menu script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao 
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
stty intr ^C
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
logPath="/root/tidbdeploy/log"
scriptsLog="$logPath/${nowTime}_03_mount_data_disk_text_menu.log"
mount_data_disk_text_menu()
{
while [ 1=1 ]
do
clear
echo "|—————————————————————————————————————————————————|"
echo "|            4.挂盘                               |"
echo "|—————————————————————————————————————————————————|"
echo "|          4.1 非tidb节点挂盘                     |"
echo "|          4.2 tidb节点挂盘                       |"
echo "|          4.3 集群节点挂盘（可自定义）           |"
echo "|—————————————————————————————————————————————————|"
echo "|          99.退出                                |"
echo "|          请输入选项：                           |"
echo "|_________________________________________________|"
read option
  case $option in
  4.1)
    clear
    echo ""
    echo '                     非tidb节点挂盘 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        sh  $scriptsPath/03_01_non_tidb_component_mount_data_disk.sh
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

  4.2)
    clear
    echo ""
    echo '                       tidb节点挂盘  [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        sh  $scriptsPath/03_02_tidb_component_mount_data_disk.sh 
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;


  4.3)
    clear
    echo ""
    echo '                       集群节点挂盘  [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        sh  $scriptsPath/03_03_all_component_mount_data_disk.sh 
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;





  99)
    stty intr ^C
    break
    ;;
  *)
    if [ "$option" == "" ];then
      echo ""
    else
      echo ""
      echo "                     选项输入错误！"
      sleep 1
    fi
                                esac  
done    

}



mount_data_disk_text_menu |tee -a ${scriptsLog}
