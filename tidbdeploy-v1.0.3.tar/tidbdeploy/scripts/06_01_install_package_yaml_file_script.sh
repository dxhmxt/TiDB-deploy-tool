
#!/bin/bash
##########################
#Script name:  06_01_install_package_yaml_file_script.sh
#Script description: xx script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
set -e 
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf

packagePath="/root/tidbdeploy/package"

scriptsPath="/root/tidbdeploy/scripts"
#dirhome=`su - $tidbInstanceUser -c "pwd"`

logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`

scriptsLog="$logPath/${nowTime}_06_01_install_package_yaml_file_script.sh"


serverDir=tidb-$communityOrEnterpriseVersion-server-$version-linux-$arch
toolkitDir=tidb-$communityOrEnterpriseVersion-toolkit-$version-linux-$arch

create_mirror_dir(){
echo "create mirror dir."
if [[ ! -d "$dirHome/mirror" ]]; then
   mkdir -p $dirHome/mirror
   chown -R $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror
   echo "$dirHome/mirror is create."
else 
   echo "$dirHome/mirror is exsit, mv mirror dir to mirror_bak,and create new mirror dir."
   mv $dirHome/mirror $dirHome/mirror_bak
   mkdir -p $dirHome/mirror
   chown -R $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror
   echo "create new $dirHome/mirror." 
fi
}


install_package_check()
{

if [ -e "$packagePath/$serverPackage" ]; then
   echo "$packagePath $serverPackage is exist."
else
   echo "$packagePath $serverPackage is not exist."
   exit 1
fi


if [ -e "$packagePath/$toolkitPackage" ]; then
   echo "$packagePath $toolkitPackage is exist."
else
   echo "$packagePath $toolkitPackage is not exist."
   exit 1
fi

}


decompress_install_package(){
echo "decompress install package to $dirHome/mirror dir."

echo "tar decompress $serverPackage package to $dirHome/mirror dir."

tar zxf   $packagePath/$serverPackage -C $dirHome/mirror
if [ $? -eq 0 ]; then
   echo "decompress  $serverPackage package is done."
  else
   echo "decompress  $serverPackage package failed, please check." 
  exit 1 
fi

echo "tar decompress $toolkitPackage package to $dirHome/mirror dir."
tar zxf   $packagePath/$toolkitPackage -C $dirHome/mirror
if [ $? -eq 0 ]; then
   echo "decompress  $toolkitPackage package is done."
  else
   echo "decompress  $toolkitPackage package failed, please check." 
  exit 1 
fi

}

install_package_auth()
{
echo "grant $tidbInstanceUser:$tidbInstanceUser to install package dir."
chown -R  $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/$serverDir
chown -R  $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/$toolkitDir 
echo "grant install package is done."
}


copy_config_file(){
echo "copy config file to $dirHome/mirror dir."
cp -f  $confPath/cluster_base_info.conf $dirHome/mirror  
echo "config file is copy ok."
}

copy_install_script(){
echo "copy install script to $dirHome/mirror dir."
cp -f  $scriptsPath/06_02_01_tidb_deploy_cluster_user.sh $dirHome/mirror 
echo "install script is copy ok."
}

copy_yaml_file()
{
echo "copy install yaml file to $dirHome/mirror dir."
cp -f  $confPath/topology.yaml $dirHome/mirror 
echo "install yaml file copy ok."

}


chown_file_auth()
{
echo "grant $tidbInstanceUser privileges to config file,install script,yaml file."
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/cluster_base_info.conf
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/06_02_01_tidb_deploy_cluster_user.sh
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/topology.yaml 
echo "config file,install script,yaml file grant $tidbInstanceUser privileges  is done."

}

copy_file_and_grant_auth_action_list()
{
create_mirror_dir
install_package_check
decompress_install_package
install_package_auth
copy_config_file
copy_yaml_file
copy_install_script
chown_file_auth
}

copy_file_and_grant_auth_action_list | tee  ${scriptsLog}
