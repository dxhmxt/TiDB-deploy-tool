
#!/bin/bash
##########################
#Script name: 05_04_dynamic_parameters_calculate.sh 
#Script description: dynamic parameters calculate for install yaml file script
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: Maxuetao
#Support platform: linux
#Change log:
#########################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_05_04_dynamic_parameters_calculate.log"

#cat   $confPath/cluster_plan.conf |awk -F" " '{print $1}' |sort -u > $confPath/iplist.txt
sed -i '{'/^$/d';'/^#/d'}'   $confPath/iplist.txt
sed -i '{'/^$/d';'/^#/d'}'    $confPath/cluster_plan.conf



clusterPlanFile=$confPath/cluster_plan.conf
clusterIpcomponentFile=$confPath/cluster_ip_component.log 
clusterCpuMemFile=$confPath/cluster_cpu_mem.log
ipComponentCpuMemFile=$confPath/ip_component_cpu_mem.log
ipListFile=$confPath/iplist.txt





get_ip_component_info()
{
rm -rf  $clusterIpcomponentFile 
cat $clusterPlanFile |awk -F " " '{print $1,$2}' >>$clusterIpcomponentFile  
}


##add 20230217 check_ip_get_ip_component funtion  
check_ip_get_ip_component()
{
cat $confPath/iplist.txt | sort  -u   >$confPath/.iplist.log  
cat  $confPath/cluster_plan.conf |awk -F " " '{print $1}' |sort  -u >$confPath/.planip.log
diff  $confPath/.iplist.log   $confPath/.planip.log
if [ $? -eq 0 ];
then  
    get_ip_component_info
else  
   echo "iplist.txt ip address and cluster_plan.conf ip address is not  consistency,please ensure consistency."
   echo "####iplist.txt ip address#########"
   cat  cat $confPath/iplist.txt
   echo "####cluster_plan.conf ip address#########"
   cat   $confPath/.planip.log   
   exit  

fi  
}



get_cpu_mem_info()
{
rm -rf  $clusterCpuMemFile  
while read line
do   
#ssh -Tq -p $sshPort  root@$line<get_cpu_mem.sh |grep -v "Last"|grep -v "There" >>$clusterCpuMemFile
ssh -Tq -p $sshPort  root@$line<get_cpu_mem.sh |grep -v "Last"|grep -v "There" |grep -v Activate| sed '{'/^$/d';'/^#/d'}' >>$clusterCpuMemFile 

 
done<$ipListFile
}






match_ip_component_and_cpu_mem_info()
{
rm -rf  $ipComponentCpuMemFile
while read line
do   
ip=`echo $line |awk '{print $1}'`
cpunum=`grep $ip $clusterCpuMemFile  |awk '{print $2}'`
memnum=`grep $ip $clusterCpuMemFile  |awk '{print $3}'`
echo $line | awk '{print $0,'$cpunum','$memnum'}' >> $ipComponentCpuMemFile
done<$clusterIpcomponentFile
}




tidb_dynamic_parameter_calculation()
{
N=`cat $ipComponentCpuMemFile |grep tikv  |awk -F" " '{print $1}' |uniq -c  |head  -1|awk -F" " '{print $1}'`
MEM_TOTAL=`cat $ipComponentCpuMemFile |grep tidb |head  -1 |awk -F" " '{print $4}'`
CPU_CNT=`cat $ipComponentCpuMemFile |grep tidb |head  -1 |awk -F" " '{print $3}'`

echo "  tidb:"
tokenlimit=`echo |awk '{print int(("'$CPU_CNT'"*5)/"'$N'")}'`
echo "    token-limit: $tokenlimit"

maxprocs=`echo |awk '{print int(("'$CPU_CNT'"*4)/5/"'$N'")}'`
echo "    performance.max-procs: $maxprocs" 


maxbackups=`echo |awk '{print int(200/"'$N'")}'`
echo "    log.file.max-backups: $maxbackups" 

###
amd64value=107374182400
arm64value=536870912000

if [ $arch != "amd64" ];then
echo "    tmp-storage-quota: $amd64value"  
elif [ $arch != "arm64" ];then
echo "    tmp-storage-quota: $arm64value"  
fi 


}


tikv_dynamic_parameter_calculation()
{
N=`cat $ipComponentCpuMemFile |grep tikv  |awk -F" " '{print $1}' |uniq -c  |head  -1|awk -F" " '{print $1}'`
MEM_TOTAL=`cat $ipComponentCpuMemFile |grep tikv |head  -1 |awk -F" " '{print $4}'`
CPU_CNT=`cat $ipComponentCpuMemFile |grep tikv |head  -1 |awk -F" " '{print $3}'`

echo "  tikv:" 
cachemem=`echo |awk '{print int(("'$MEM_TOTAL'"/2)/"'$N'")}'`
echo "    storage.block-cache.capacity: "$cachemem"G"


readcount=`echo |awk '{print int(("'$CPU_CNT'"*4)/"'$N'")}'`
echo "    readpool.unified.max-thread-count: $readcount"

servercon=`echo |awk '{print int("'$CPU_CNT'"/"'$N'")}'`
echo "    server.end-point-max-concurrency: $servercon"

}


tiflash_dynamic_parameter_calculation()
{
N=`cat $ipComponentCpuMemFile |grep tiflash  |awk -F" " '{print $1}' |uniq -c  |head  -1|awk -F" " '{print $1}'`
MEM_TOTAL=`cat $ipComponentCpuMemFile |grep tiflash |head  -1 |awk -F" " '{print $4}'`
CPU_CNT=`cat $ipComponentCpuMemFile |grep tiflash |head  -1 |awk -F" " '{print $3}'`

echo "  tiflash:" 
querymem=`echo |awk '{print int(("'$MEM_TOTAL'"*0.7)/"'$N'")}'`
echo "    profiles.default.max_memory_usage_for_all_queries: "$querymem"G"


threads=`echo |awk '{print int(("'$CPU_CNT'"*4)/"'$N'")}'`
echo "    profiles.default.max_threads: $threads"

}




component_calculation(){

tidbnum=`cat   $ipComponentCpuMemFile |grep tidb |wc  -l`
if [ $tidbnum -ne 0 ];then  
   tidb_dynamic_parameter_calculation
fi  

tikvnum=`cat   $ipComponentCpuMemFile |grep tikv |wc  -l`
if [ $tikvnum -ne 0 ];then  
   tikv_dynamic_parameter_calculation
fi  

tiflushnum=`cat   $ipComponentCpuMemFile |grep tiflash |wc  -l`
if [ $tiflushnum -ne 0 ];then 
   tiflash_dynamic_parameter_calculation 
fi  
}

main(){
check_ip_get_ip_component 
get_cpu_mem_info 
match_ip_component_and_cpu_mem_info
component_calculation
}

main  |tee  ${scriptsLog}
