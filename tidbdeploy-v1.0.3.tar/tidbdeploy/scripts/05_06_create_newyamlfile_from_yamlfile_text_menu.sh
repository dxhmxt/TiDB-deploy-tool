

#!/bin/bash
##########################
#Script name: 05_06_create_newyamlfile_from_yamlfile_text_menu.sh 
#Script description: create newyamlfile from yamlfile text menu script 
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao 
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
logPath="/root/tidbdeploy/log"
scriptsLog="$logPath/${nowTime}_01_set_root_ssh_mutual_trust_text_menu.log"
create_newyamlfile_from_yamlfile_text_menu()
{
while [ 1=1 ]
do
clear
echo "|—————————————————————————————————————————————————|"
echo "|          6.5.快速生成相同架构规划yaml文件       |"
echo "|—————————————————————————————————————————————————|"
echo "|          6.5.1 编辑两个集群ip列表               |"
echo "|          6.5.2 生成相同架构规划yaml文件         |"
echo "|—————————————————————————————————————————————————|"
echo "|          99.退出                                |"
echo "|          请输入选项：                           |"
echo "|_________________________________________________|"
read option
  case $option in
  6.5.1)
    clear
    echo ""
    echo '                     编辑两个集群ip列表 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
                echo "编辑两个集群ip列表a_and_b_iplist.txt"
        vim  $confPath/a_and_b_iplist.txt
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

  6.5.2)
    clear
    echo ""
    echo '                       生成相同架构规划yaml文件  [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        sh  $scriptsPath/05_06_01_create_newyamlfile_from_yamlfile.sh 
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

 

  99)
    stty intr ^C
    break
    ;;
  *)
    if [ "$option" == "" ];then
      echo ""
    else
      echo ""
      echo "                     选项输入错误！"
      sleep 1
    fi
                                esac  
done    

}



create_newyamlfile_from_yamlfile_text_menu |tee ${scriptsLog}


