
#!/bin/bash
##########################
#Script name:  04_create_cluster_user_and_set_mutual_trust_text_menu.sh
#Script description: create cluster user and set mutual trust text menu script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################

scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
logPath="/root/tidbdeploy/log"

stty intr ^C
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_04_create_cluster_user_and_set_mutual_trust_text_menu.log"


create_cluster_user_and_set_mutual_trust_text_menu()
{
while [ 1=1 ]
do
clear
echo "|—————————————————————————————————————————————————|"
echo "|            5.设置集群实例用户互信               |"
echo "|—————————————————————————————————————————————————|"
echo "|          5.1 创建集群实例用户                   |"
echo "|          5.2 设置集群实例用户互信               |"
echo "|          5.3 检查集群实例用户互信               |"
echo "|—————————————————————————————————————————————————|"
echo "|          99.退出                                |"
echo "|          请输入选项：                           |"
echo "|_________________________________________________|"
read option
  case $option in
  

  
  
  5.1)
    clear
    echo ""
    echo '                     创建集群实例用户 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        sh  $scriptsPath/04_02_loop_create_cluster_user.sh
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

  5.2)
    clear
    echo ""
    echo '                       设置集群实例用户互信  [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        sh  $scriptsPath/04_03_set_cluster_user_ssh_mutual_trust.sh
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

  5.3)
    clear
    echo ""
    echo '                       检查集群实例用户互信 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        sh  $scriptsPath/04_04_check_cluster_user_ssh_mutual_trust.sh
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;



  99)
    stty intr ^C
    break
    ;;
  *)
    if [ "$option" == "" ];then
      echo ""
    else
      echo ""
      echo "                     选项输入错误！"
      sleep 1
    fi
                                esac  
done    

}



create_cluster_user_and_set_mutual_trust_text_menu |tee ${scriptsLog}
