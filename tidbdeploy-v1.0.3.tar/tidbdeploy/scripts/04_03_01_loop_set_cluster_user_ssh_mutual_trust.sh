

#!/bin/bash
##########################
#Script name:  04_03_01_loop_set_cluster_user_ssh_mutual_trust.sh 
#Script description: set instance user huxin script
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################



source ./cluster_base_info.conf
logPath="./"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_04_03_01_loop_set_cluster_user_ssh_mutual_trust.log"


create_rsa()
{
ssh-keygen -t rsa -P '' -f ~/.ssh/id_rsa
}


set_instance_mutual_trust()
{
echo "set instance user huxin."
for line in `cat iplist.txt`
do

echo  $line
expect -c " 
  spawn ssh-copy-id -p $sshPort -o StrictHostKeyChecking=no $tidbInstanceUser@$line
  expect \"password:\" 
  send \"${tidbInstanceUserPassword}\r\"
  expect eof
  "
done
}


check_instance_mutual_trust()
{
echo "check instance user huxin."
for line in `cat iplist.txt`

do
ssh  -Tq -p  $sshPort $tidbInstanceUser@$line "hostname -I;date"
if [ $? -eq 0 ];then 
   echo "$line $tidbInstanceUser ssh mutual trust is ok."
else 
   echo "$line $tidbInstanceUser ssh mutual trust is not ok."
fi  

done
}

loop_set_cluster_user_ssh_mutual_trust()
{
create_rsa
set_instance_mutual_trust
#check_instance_mutual_trust
}

#loop_set_cluster_user_ssh_mutual_trust |tee  ${scriptsLog} 
loop_set_cluster_user_ssh_mutual_trust

