confPath="/root/tidbdeploy/conf"
cat  $confPath/readme 
