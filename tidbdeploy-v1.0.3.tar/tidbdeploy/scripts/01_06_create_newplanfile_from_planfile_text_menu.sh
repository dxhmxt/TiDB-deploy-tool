
#!/bin/bash
##########################
#Script name: 01_06_create_newplanfile_from_planfile_text_menu.sh 
#Script description: create newplanfile from newplanfile text menu script 
#Created Date:2023/02/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao 
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
logPath="/root/tidbdeploy/log"
scriptsLog="$logPath/${nowTime}_01_06_create_newplanfile_from_planfile_text_menu.log"
create_newplanfile_from_planfile_text_menu()
{
while [ 1=1 ]
do
clear
echo "|—————————————————————————————————————————————————|"
echo "|        1.6.快速生成相同架构集群拓扑规划文件     |"
echo "|—————————————————————————————————————————————————|"
echo "|          1.6.1 编辑两个集群ip列表               |"
echo "|          1.6.2 生成相同架构集群拓扑规划文件     |"
echo "|—————————————————————————————————————————————————|"
echo "|          99.退出                                |"
echo "|          请输入选项：                           |"
echo "|_________________________________________________|"
read option
  case $option in
  1.6.1)
    clear
    echo ""
    echo '                     编辑两个集群ip列表 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
                echo "编辑两个集群ip列表a_and_b_iplist.txt"
        vim  $confPath/a_and_b_iplist.txt
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

  1.6.2)
    clear
    echo ""
    echo '                       生成相同架构集群拓扑规划文件  [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
#       sh  $scriptsPath/05_06_01_create_newyamlfile_from_yamlfile.sh
        sh  $scriptsPath/01_06_01_create_newplanfile_from_planfile.sh 
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;

 

  99)
    stty intr ^C
    break
    ;;
  *)
    if [ "$option" == "" ];then
      echo ""
    else
      echo ""
      echo "                     选项输入错误！"
      sleep 1
    fi
                                esac  
done    

}



create_newplanfile_from_planfile_text_menu |tee ${scriptsLog}
