
#!/bin/bash
##########################
#Script name: edit_cluster_deployment_related_configuration_files_menu.sh 
#Script description: edit_cluster_deployment_related_configuration_files menu script
#Created Date:2023/02/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao 
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
stty intr ^C
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
logPath="/root/tidbdeploy/log"
scriptsLog="$logPath/${nowTime}_edit_cluster_deployment_related_configuration_files_menu.log"


edit_cluster_deployment_related_configuration_files()
{
while [ 1=1 ]
do
clear
echo "|—————————————————————————————————————————————————|"
echo "|            1.编辑集群部署相关配置文件           |"
echo "|—————————————————————————————————————————————————|"
echo "|          1.1 编辑集群部署初始配置文件           |"
echo "|          1.2 集群拓扑规划模板1-最小配置         |"
echo "|          1.3 集群拓扑规划模板2-简单配置         |"
echo "|          1.4 集群拓扑规划模板3-详细配置         |"
echo "|          1.5 编辑集群拓扑规划文件               |"
echo "|          1.6 快速生成相同架构集群拓扑规划文件   |"
echo "|          1.7 编辑集群ip列表                     |"
echo "|—————————————————————————————————————————————————|"
echo "|          99.退出                                |"
echo "|          请输入选项：                           |"
echo "|_________________________________________________|"
read option
  case $option in
  1.1)
    clear
    echo ""
    echo '                     编辑集群初始配置文件 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了是 "
        sleep 1
        clear
                echo "编辑集群初始配置文件cluster_base_info.conf"
        vim  $confPath/cluster_base_info.conf
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了否"
        sleep 1
        ;;
                esac    
    ;;


  1.2)
    clear
    echo ""
    echo '                     集群拓扑规划模板1 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了是 "
        sleep 1
        clear
        cat  $confPath/cluster_plan.conf.example1
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了否"
        sleep 1
        ;;
                esac    
    ;;


  1.3)
    clear
    echo ""
    echo '                     集群拓扑规划模板2 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了是 "
        sleep 1
        clear
        cat  $confPath/cluster_plan.conf.example2
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了否"
        sleep 1
        ;;
                esac    
    ;;


  1.4)
    clear
    echo ""
    echo '                     集群拓扑规划模板3 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了是"
        sleep 1
        clear
        cat  $confPath/cluster_plan.conf.example3
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了否"
        sleep 1
        ;;
                esac    
    ;;


  1.5)
    clear
    echo ""
    echo '                     编辑集群拓扑规划文件 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了是 "
        sleep 1
        clear
        echo "编辑集群拓扑规划文件cluster_plan.conf"
            vim  $confPath/cluster_plan.conf
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了否"
        sleep 1
        ;;
                esac    
    ;;



  1.6)
    clear
    echo ""
    echo '                     快速生成相同架构集群拓扑规划文件 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了是 "
        sleep 1
        clear
        sh  $scriptsPath/01_06_create_newplanfile_from_planfile_text_menu.sh
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了否"
        sleep 1
        ;;
                esac    
    ;;



  1.7)
    clear
    echo ""
    echo '                     编辑集群ip列表 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了是 "
        sleep 1
        clear
        echo "编辑集群ip列表"
        vim  $confPath/iplist.txt
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了否"
        sleep 1
        ;;
                esac    
    ;;






  99)
    stty intr ^C
    break
    ;;
  *)
    if [ "$option" == "" ];then
      echo ""
    else
      echo ""
      echo "                     选项输入错误！"
      sleep 1
    fi
                                esac  
done    

}



edit_cluster_deployment_related_configuration_files |tee ${scriptsLog}
