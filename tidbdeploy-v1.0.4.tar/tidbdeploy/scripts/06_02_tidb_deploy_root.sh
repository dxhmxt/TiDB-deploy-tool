#!/bin/bash
##########################
#Script name:  06_02_tidb_deploy_root.sh 
#Script description: xx script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
set -e

scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_06_02_tidb_deploy_root.log"
#dirHome=`su - $tidbInstanceUser -c "pwd"`
echo $tidbInstanceUser
echo $dirHome 


tidb_deploy()
{
echo "tidb deploy."
su - $tidbInstanceUser -c "sh $dirHome/mirror/06_02_01_tidb_deploy_cluster_user.sh"

}


tidb_deploy |tee  ${scriptsLog}
