#!/bin/bash
##########################
#Script name:  08_01_02_01_cluseter_instance_user_set_tidb_root_password.sh
#Script description: cluster instance user change tidb root password script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
set -e
source ./mirror/cluster_base_info.conf


tidbHostName=`tiup cluster display $clusterName |awk -F" " '{print $1,$2}'|grep tidb |head -n1 |awk -F":" '{print $1}'`
tidbPort=`tiup cluster display $clusterName |awk -F" " '{print $1,$2}'|grep tidb |head -n1 |awk -F":" '{print $2}'|awk -F" " '{print $1}'`



cluster_user_set_tidb_root_password(){
mysql  -h$tidbHostName -P$tidbPort -u$tidbDatabaseUserRoot   -e"update mysql.user set authentication_string=password('$tidbDatabaseUserRootPassword') where user='root'; flush privileges;"
mysql  -h$tidbHostName -P$tidbPort -u$tidbDatabaseUserRoot -p$tidbDatabaseUserRootPassword  -e"select 1;"
if [ $? -eq 0 ];then 
    echo "change tidb root password done."
else 
    echo "change tidb root password failed."
fi
}

cluster_user_set_tidb_root_password
