#!/bin/bash
##########################
#Script name: 03_01_01_non_tidb_component_mount_data_disk.sh
#Script description: mount non tidb component  data disk  child script
#sh setsysfor.sh 
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: Maxuetao
#Support platform: linux
#Change log:
#########################
scriptsPath="/root/tidbdeploy/scripts"


mkfs_data_disk_ext4(){
echo "mkfs data disk format ext4."
mkfs.ext4 /dev/nvme0n1
mkfs.ext4 /dev/nvme1n1
mkfs.ext4 /dev/nvme2n1
mkfs.ext4 /dev/nvme3n1
echo "mkfs data disk format done."
}


mk_data_dir()
{
echo "mkdir mount disk dir."
mkdir /data{1..4}
echo "mkdir data disk dir done."
}


mount_data_disk_dir()
{
echo "mount data disk dir."
mount -t ext4 -o defaults,notime,nodelalloc /dev/nvme0n1 /data1
mount -t ext4 -o defaults,notime,nodelalloc /dev/nvme1n1 /data2
mount -t ext4 -o defaults,notime,nodelalloc /dev/nvme2n1 /data3
mount -t ext4 -o defaults,notime,nodelalloc /dev/nvme3n1 /data4
}


change_fstab_file()
{
echo "change fstab file"
cat <<EOF>> /etc/fstab 
/dev/nvme0n1 /data1 ext4 defaults,notime,nodelalloc  0  0 
/dev/nvme1n1 /data2 ext4 defaults,notime,nodelalloc  0  0 
/dev/nvme2n1 /data3 ext4 defaults,notime,nodelalloc  0  0 
/dev/nvme3n1 /data4 ext4 defaults,notime,nodelalloc  0  0 
EOF
}

check_disk_dir()
{
df -h |grep data
cat  /etc/fstab |grep data

}


mount_data_disk_dir_list()
{
mkfs_data_disk_ext4
mk_data_dir
mount_data_disk_dir
change_fstab_file
check_disk_dir
}

mount_data_disk_dir_list

