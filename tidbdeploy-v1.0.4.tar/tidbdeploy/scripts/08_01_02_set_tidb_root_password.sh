
#!/bin/bash
##########################
#Script name:  08_01_02_set_tidb_root_password.sh
#Script description: set tidb root password script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
set -e
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_08_01_02_set_tidb_root_password.log"

sed -i '{'/^$/d';'/^#/d'}'    $confPath/cluster_plan.conf


cpoy_conf_script_file(){
echo "cpoy conf script file to  $dirHome."

cp -f  $confPath/cluster_plan.conf $dirHome/mirror
cp -f  $confPath/cluster_base_info.conf $dirHome/mirror
cp -f  $scriptsPath/08_01_02_01_cluseter_instance_user_set_tidb_root_password.sh $dirHome/mirror
}

chown_conf_script_file_auth()
{
echo "chown conf and script file instance user grant."
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/cluster_plan.conf
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/cluster_base_info.conf
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/mirror/08_01_02_01_cluseter_instance_user_set_tidb_root_password.sh
}


set_tidb_root_password()
{
echo "set tidb database root password."
su - $tidbInstanceUser -c "sh $dirHome/mirror/08_01_02_01_cluseter_instance_user_set_tidb_root_password.sh"
}

root_set_tidb_root_password()
{
cpoy_conf_script_file
chown_conf_script_file_auth
set_tidb_root_password
}


root_set_tidb_root_password |tee  ${scriptsLog}
