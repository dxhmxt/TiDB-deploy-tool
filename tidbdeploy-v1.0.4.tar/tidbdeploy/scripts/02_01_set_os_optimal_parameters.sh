
#!/bin/bash
##########################
#Script name:  02_01_set_os_optimal_parameters.sh 
#Script description: set os optimal parameters script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
set -e


nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="./${nowTime}_02_01_set_os_optimal_parameters.log"

cp /etc/sysctl.conf /etc/sysctl.conf.${nowTime}.bak  



##add vm.swappiness = 0
disable_swap()
{
echo "starting set disableswap."
echo "vm.swappiness = 0">> /etc/sysctl.conf
#swapoff -a && sysctl -p
echo "disableswap set done."
}



swappiness_disable_set()
{
validswaprownum=`sed -n  '/vm.swappiness/p' /etc/sysctl.conf|grep -v "#" |awk -F " " '{print $3}' |uniq |wc  -l`
##valid swappiness rows.

if [ $validswaprownum -eq 0 ];then
   echo "vm.swappiness not exits,need to be set." 
   disable_swap
else 
  echo "vm.swappiness need to delete,and new add vm.swappiness = 0."
  echo "delete vm.swappiness through sed matching."
  sed -i  '/vm.swappiness/d' /etc/sysctl.conf
  echo "delete vm.swappiness done."
  disable_swap
fi  
}

###可以重复执行 
firewalld_stop()
{
echo "starting set firewalldstop."
systemctl stop firewalld
systemctl disable firewalld
echo "firewalldstop and disable done."
}

###关闭selinux  
seliunx_disable()
{
echo "selinuxstate check and disable set."
selinuxstate=`getenforce`

if [ $selinuxstate = "Disabled" ];then 
   echo "selinux state is disabled."
else
   if [ $selinuxstate = "Enforcing"];then 
      echo "starting set seliunxdisable."
          setenforce 0
      sed -i 's#SELINUX=enforcing#SELINUX=disabled#' /etc/selinux/config
      echo "seliunxdisable set done,os is need reboot."
   else 
      "please check selinux state."
   fi
fi  
}



kernel_set()
{
echo "starting set kernelset."
sed -i  '/fs.file-max/d' /etc/sysctl.conf
sed -i  '/net.core.somaxconn/d' /etc/sysctl.conf
sed -i  '/net.ipv4.tcp_tw_recycle/d' /etc/sysctl.conf
sed -i  '/net.ipv4.tcp_syncookies/d' /etc/sysctl.conf
sed -i  '/vm.overcommit_memory/d' /etc/sysctl.conf

cat << EOF >>/etc/sysctl.conf
fs.file-max = 1000000
net.core.somaxconn = 32768
net.ipv4.tcp_tw_recycle = 0
net.ipv4.tcp_syncookies = 0
vm.overcommit_memory = 1
EOF
echo "kernelset set done."
}


limits_set()
{
sed -i '/^ /d' /etc/security/limits.conf
limitfilerow=`grep -E "nofile|stack"  /etc/security/limits.conf |grep $tidbInstanceUser |wc  -l`
if [ $limitfilerow -eq 4 ];then 
   echo "$tidbInstanceUser limitsset is set."
   sed -i "/$tidbInstanceUser/d" /etc/security/limits.conf
else 
   sed -i "/$tidbInstanceUser/d" /etc/security/limits.conf
   echo "delete unnecessary tidbInstanceUser $tidbInstanceUser limitsset info"

fi 

echo "starting set limitsset."
cat << EOF >>/etc/security/limits.conf
$tidbInstanceUser           soft    nofile          1000000
$tidbInstanceUser           hard    nofile          1000000
$tidbInstanceUser           soft    stack          32768
$tidbInstanceUser           hard    stack          32768
EOF
echo "limitsset set done."
}


sudo_set()
{
echo "starting set $tidbInstanceUser sudo set."
sudosetrow=`grep -i nopasswd  /etc/sudoers |grep -v "#"|grep $tidbInstanceUser |wc  -l`
if [ $sudosetrow -eq 1 ];then
   echo "$tidbInstanceUser sudo grant is set."
else 
   sed -i "/$tidbInstanceUser/d" /etc/sudoers
   echo "delete unnecessary $tidbInstanceUser sudo grant info"
   echo "starting set $tidbInstanceUser sudo set."
   echo "$tidbInstanceUser ALL=(ALL) NOPASSWD: ALL" >>/etc/sudoers
   echo "$tidbInstanceUser sudo grant set  done."
fi 
echo "$tidbInstanceUser sudo  set done."
}




virtual_machine_thp_set()
{
cat << EOF >>/etc/tuned/balanced-tidb-optimal/tuned.conf
[main]
include=balanced

[vm]
transparent_hugepage=never

EOF
tuned-adm profile balanced-tidb-optimal
}



physical_machine_cpuper_and_thp_set()
{
cat << EOF >>/etc/tuned/balanced-tidb-optimal/tuned.conf
[main]
include=balanced


[vm]
transparent_hugepage=never

EOF
tuned-adm profile balanced-tidb-optimal
}


machine_type_check_set()
{
echo "machine type check."
machinetype=`systemd-detect-virt`

if [ $machinetype = "none" ];then
   echo "machine type is physical machine." 
   physical_machine_cpuper_and_thp_set
   echo "physical machine cpuper and thp set done,TIPS restart the system setting takes effect."
else 
   echo "machine type is virtual machine." 
   virtual_machine_thp_set
   echo "virtual machine thp set done,TIPS restart the system setting takes effect."
fi 

}

cpuper_and_thp_set()
{
tunedfile="/etc/tuned/balanced-tidb-optimal/tuned.conf"
tuneddir="/etc/tuned/balanced-tidb-optimal/"
if [ ! -f "$tunedfile" ]; then
      if [ ! -d "$tuneddir" ]; then
         mkdir $tuneddir
                 echo "$tuneddir is create."
                 touch $tunedfile
                 echo "$tunedfile is touch."
                 machine_type_check_set
      fi   
else 
     echo "backup $tunedfile to $tunedfile.bak."
     mv $tunedfile $tunedfile.bak 
         touch $tunedfile
         machine_type_check_set
fi
}


system_judgment()
{
if [ -f "/etc/kylin-release" ];then
  echo "this is kylin-release system."
else 
  echo "this is not kylin-release system. will be cpup and thp set."
  cpuper_and_thp_set
fi

}


check_cpuper_and_thp_set()
{
if [ -f "/etc/kylin-release" ];then
  echo "this is kylin-release system."
  echo "this is not check cpuper_and_thp_set."
else 
  echo "this is not kylin-release system. will be cpup and thp set."
  cat /etc/tuned/balanced-tidb-optimal/tuned.conf

fi

}



check_set_results()
{
echo "#############start check os optimal parameters set############"
echo "##check swappinessdisableset."
sed -n  '/vm.swappiness/p' /etc/sysctl.conf|grep -v "#" 

echo "##check seliunx disable set."
selinuxstate=`getenforce`
echo "seliunx is $selinuxstate." 

echo "##check kernelset."
sed -n  '/fs.file-max/p' /etc/sysctl.conf
sed -n  '/net.core.somaxconn/p' /etc/sysctl.conf
sed -n  '/net.ipv4.tcp_tw_recycle/p' /etc/sysctl.conf
sed -n  '/net.ipv4.tcp_syncookies/p' /etc/sysctl.conf
sed -n  '/vm.overcommit_memory/p' /etc/sysctl.conf

echo "##check limitsset."
grep -E "nofile|stack"  /etc/security/limits.conf |grep $tidbInstanceUser 

echo "##check tidbInstanceUsersudoset."
grep -i nopasswd  /etc/sudoers |grep -v "#"|grep $tidbInstanceUser

echo "##check cpuper_and_thp_set."
check_cpuper_and_thp_set

}




main()
{
swappiness_disable_set
seliunx_disable
kernel_set
limits_set
sudo_set
system_judgment
check_set_results
}

main  
