
##########################
#Script name:  01_06_01_create_newplanfile_from_planfile.sh
#Script description: create newplanfile from planfile script
#Created Date:2023/02/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_01_06_01_create_newplanfile_from_planfile.log"


planFile=$confPath/cluster_plan.conf


aAndBIpListFile=$confPath/a_and_b_iplist.txt

sed -i '{'/^$/d';'/^#/d'}'  $aAndBIpListFile 

create_newplanfile_from_planfile()
{
echo "backup $planFile to $planFile.$nowTime."
cp $planFile $planFile.$nowTime 

while read line
do
w=`echo $line  |awk '{print $1}'`
f=`echo $line  |awk '{print $2}'`
sed -i "s/${w}/${f}/g"   $planFile
done < $aAndBIpListFile
}

main()
{
create_newplanfile_from_planfile 
echo "please check new plan file $planFile, and check old plan file $planFile.$nowTime."

echo "#######this is new plan file $planFile."
cat  $planFile 

echo "####################################################################################"
echo " " 
echo "####################################################################################"

echo "#######this is old plan file $planFile.$nowTime."

cat  $planFile.$nowTime
}

main |tee   ${scriptsLog}
