#!/bin/bash
##########################
#Script name: 03_01_tidb_component_mount_data_disk.sh 
#Script description:  tidb component mount data disk script
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: Maxuetao
#Support platform: linux
#Change log:
#########################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_03_02_tidb_component_mount_data_disk.log"

sed -i '{'/^$/d';'/^#/d'}'    $confPath/cluster_plan.conf


#提取tidb ip
mount_data_disk()
{
for line in `cat $confPath/cluster_plan.conf  |awk -F" " '{print $1,$2}'  |grep  tidb |awk -F" " '{print $1}'|sort -u`
do
  echo  "$line tidb component $nowTime start mount data disk."
  ssh -Tq -p $sshPort root@$line <03_02_01_tidb_component_mount_data_disk.sh
  echo  "$line  tidb component $nowTime start mount data disk done."
done
}

mount_data_disk |tee  ${scriptsLog}
