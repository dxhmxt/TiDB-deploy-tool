

#!/bin/bash
##########################
#Script name:  00_tidb_deploy_text_menu.sh
#Script description: tidb deploy main script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
logPath="/root/tidbdeploy/log"
scriptsLog="$logPath/${nowTime}_00_tidb_deploy_text_menu.log"

tidb_deploy_menu()
{
while [ 1=1 ]
do
clear
echo " ____________________________________________________ "
echo "|                  TiDB部署助手工具                  |"
echo "|=====================功能菜单=======================|"
echo "|          1.编辑集群部署相关配置文件                |"
echo "|          2.设置系统root用户互信                    |"
echo "|          3.初始化操作系统参数                      |"
echo "|          4.挂载数据盘                              |"
echo "|          5.创建集群实例用户和设置互信              |"
echo "|          6.生成yaml配置文件                        |"
echo "|          7.部署集群                                |"
echo "|          8.设置数据库root用户密码                  |"
echo "|          9.初始化数据库参数                        |"
echo "|          10.TiDB部署工具介绍和部署说明             |"
echo "|————————————————————————————————————————————————————|"
echo "|          99.退出                                   |"
echo "|          请输入选项：                              |"
echo "|____________________________________________________|"
read option
  case $option in

  1)
    clear
    echo ""
    echo '                     编辑集群部署相关配置文件 [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        clear
        scripts_name=$scriptsPath/edit_cluster_deployment_related_configuration_files_menu.sh	
        clear
        sh $scripts_name		
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
                esac    
    ;;


  2)
    clear
    echo ""
    echo '                    设置系统root用户互信[y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        scripts_name=$scriptsPath/01_set_root_ssh_mutual_trust_text_menu.sh
        clear
        sh $scripts_name
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
    esac    
    ;;  

  3)
    clear
    echo ""
    echo '                    初始化系统参数[y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        scripts_name=$scriptsPath/02_loop_set_os_optimal_parameters.sh
        clear
        sh $scripts_name
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
    esac    
    ;;  

  4)
    clear
    echo ""
    echo '                    挂载数据盘[y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        scripts_name=$scriptsPath/03_mount_data_disk_text_menu.sh
        clear
        sh $scripts_name
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
    esac    
    ;;  

  5)
    clear
    echo ""
    echo '                    创建集群实例用户和设置互信[y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        scripts_name=$scriptsPath/04_create_cluster_user_and_set_mutual_trust_text_menu.sh 
        clear
        sh $scripts_name
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
    esac    
    ;;  

  6)
    clear
    echo ""
    echo '                    生成部署yaml文件[y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        scripts_name=$scriptsPath/05_create_cluster_topology_file_text_menu.sh
        clear
        sh $scripts_name
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
    esac    
    ;;  

  7)
    clear
    echo ""
    echo '                    部署集群[y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        scripts_name=$scriptsPath/06_tidb_deploy_text_menu.sh
        clear
        sh $scripts_name
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
    esac    
    ;;  

  8)
    clear
    echo ""
    echo '              设置数据库root用户密码  [y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        scripts_name=$scriptsPath/08_01_change_tidb_root_password_menu.sh
        clear
        sh $scripts_name
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
    esac    
    ;;  

  9)
    clear
    echo ""
    echo '                    初始化数据库变量参数[y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        scripts_name=$scriptsPath/09_initialize_database_variable_parameters_menu.sh
        clear
        sh $scripts_name
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
    esac    
    ;;  

  10)
    clear
    echo ""
    echo '                    TiDB部署工具介绍和部署说明[y/n]'
    read ANS;
    until [[ $ANS = 'y' || $ANS = 'n' || $ANS = 'Y' || $ANS = 'N' ]]
    do
       echo "                     请重新输入:"
       read ANS;
    done
    case $ANS in
    y|Y) 
        echo "                     你选择了 是 "
        sleep 1
        scripts_name=$scriptsPath/09_banben.sh
        clear
        sh $scripts_name
        echo "                     输入任意键继续"
        read pause      
        echo ""
        ;;
    n|N) 
        echo "                     你选择了 否"
        sleep 1
        ;;
    esac    
    ;;  

  99)
    stty intr ^C
    break
    ;;
  *)
    if [ "$option" == "" ];then
      echo ""
    else
      echo ""
      echo "                     选项输入错误！"
      sleep 1
    fi
  esac  
done    

}

tidb_deploy_menu |tee  ${scriptsLog}
