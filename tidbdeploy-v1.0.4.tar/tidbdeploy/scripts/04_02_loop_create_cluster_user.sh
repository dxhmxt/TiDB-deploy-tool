
#!/bin/bash
##########################
#Script name:  04_02_loop_create_cluster_user.sh
#Script description: loop create cluster instance user script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################



confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
scriptsPath="/root/tidbdeploy/scripts"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
logPath="/root/tidbdeploy/log"
scriptsLog="$logPath/${nowTime}_04_02_loop_create_cluster_user.log"

#cat   $confPath/cluster_plan.conf |awk -F" " '{print $1}' |sort -u > $confPath/iplist.txt

instanceUserInfo=`cat $confPath/cluster_base_info.conf|grep  tidbInstanceUser  |head -n1`
instanceUserPasswordInfo=`cat $confPath/cluster_base_info.conf|grep  tidbInstanceUserPassword`
instanceDirHomeInfo=`cat $confPath/cluster_base_info.conf|grep  dirHome`

initial_useradd_script_variable()
{
echo "init useradd script variable."

sed  -i "/nowTime/a $instanceUserInfo" useradd.sh 
sed  -i "/nowTime/a $instanceUserPasswordInfo" useradd.sh 
sed  -i "/nowTime/a $instanceDirHomeInfo" useradd.sh 
}

scp_initial_useradd_script_to_cluster_all_ip()
{
for line in `cat $confPath/iplist.txt`
do
scp  -P $sshPort $scriptsPath/useradd.sh  root@$line:/tmp
echo "scp useradd.sh to $line."
done
}



loop_add_instance_user()
{
for line in `cat $confPath/iplist.txt`
do
ssh  -Tq -p $sshPort root@$line "sh /tmp/useradd.sh"
echo "$line execute useradd.sh."
done

}


restore_useradd_script()
{
sed -i "/^tidbInstanceUser/d" useradd.sh
sed -i "/^dir/d"   useradd.sh  
echo "restore useradd script done."
}

main()
{
initial_useradd_script_variable
scp_initial_useradd_script_to_cluster_all_ip
loop_add_instance_user
restore_useradd_script
}

main  |tee  ${scriptsLog}
