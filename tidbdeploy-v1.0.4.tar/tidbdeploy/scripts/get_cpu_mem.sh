
osmem=`free  -h|grep -i mem  |awk -F" " '{print $2}'|awk -F'G' '{print $1}'`
oscpu=`cat /proc/cpuinfo |grep pro|wc  -l`
hostname -I>.hs.log
awk '{print $0,"'$oscpu'","'$osmem'"}' .hs.log

