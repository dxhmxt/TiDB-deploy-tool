#!/bin/bash
##########################
#Script name: 03_02_01_tidb_component_mount_data_disk.sh
#Script description: mount  tidb component  data disk  child script
#sh setsysfor.sh 
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: Maxuetao
#Support platform: linux
#Change log:
#########################
scriptsPath="/root/tidbdeploy/scripts"


mkfs_data_disk_ext4(){
echo "mkfs data disk format ext4."
mkfs.ext4 /dev/sda5
echo "mkfs data disk format done."
}


mk_data_dir()
{
echo "mkdir mount disk dir."
mkdir /data1
echo "mkdir data disk dir done."
}


mount_data_disk_dir()
{
echo "mount data disk dir."
mount -t ext4 -o defaults,notime,nodelalloc /dev/sda5 /data1
}


mk_data_and_tmp_dir()
{
echo "mkdir data and tmp dir."
mkdir -p /data1/tidb
mkdir -p /data1/tidbtmp

}

change_fstab_file()
{
echo "change fstab file"
cat <<EOF>> /etc/fstab 
/dev/sda5 /data1 ext4 defaults,notime,nodelalloc  0  0 
EOF
}

check_disk_dir()
{
df -h |grep data
cat  /etc/fstab |grep data

}


mount_data_disk_dir_list()
{
mkfs_data_disk_ext4
mk_data_dir
mount_data_disk_dir
change_fstab_file
mk_data_and_tmp_dir
check_disk_dir
}

mount_data_disk_dir_list
