
#!/bin/bash
##########################
#Script name:  01_01_check_root_ssh_mutual_trust.sh
#Script description: check root huxin script
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_01_01_check_root_ssh_mutual_trust.log"
osUserRoot=root



check_root_mutual_trust()
{
echo "check root huxin."
sed -i '{'/^$/d';'/^#/d'}'   $confPath/iplist.txt


for line in `cat $confPath/iplist.txt`

do
ssh -Tq -p $sshPort $osUserRoot@$line "hostname -I;date"
if [ $? -eq 0 ];then 
   echo "$line ssh mutual trust is ok."
else 
   echo "$line ssh mutual trust is not ok."
fi  
done
}

check_root_mutual_trust |tee ${scriptsLog}
