#!/bin/bash
##########################
#Script name:  04_04_01_check_cluster_user_ssh.sh
#Script description: check instance huxin script
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

source ./cluster_base_info.conf
logPath="./"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_04_04_01_check_cluster_user_ssh.log"




check_instance_mutual_trust()
{
for line in `cat iplist.txt`

do
ssh -Tq -p $sshPort $tidbInstanceUser@$line "hostname -I;date"
if [ $? -eq 0 ];then 
   echo "$line $tidbInstanceUser ssh mutual trust is ok."
else 
   echo "$line $tidbInstanceUser ssh mutual trust is not ok."
fi 

done
}

#check_instance_mutual_trust |tee  ${scriptsLog}
check_instance_mutual_trust

