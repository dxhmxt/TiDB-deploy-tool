
#!/bin/bash
##########################
#Script name:  05_05_create_cluster_deploy_topology_file.sh
#Script description: create cluster component topology file script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################


confPath="/root/tidbdeploy/conf"
logPath="/root/tidbdeploy/log"
source $confPath/cluster_base_info.conf
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_05_05_create_cluster_deploy_topology_file.log"


create_cluster_deploy_topology_file()
{
cp $confPath/topology.yaml $confPath/topology.yaml.${nowTime}.bak
rm -rf  $confPath/topology.yaml
cat $confPath/cluster_global.conf >> $confPath/topology.yaml 
cat $confPath/ip_component_yaml.txt  >> $confPath/topology.yaml 
##20230215 add grafanaUserPassword set.
grafuserpasswd=`echo "   password: $grafanaUserPassword"` 
sed -irn '/password/d' $confPath/topology.yaml 
sed  -irn "/username/a\ $grafuserpasswd" $confPath/topology.yaml

echo "再次确认topology.yaml"
vim $confPath/topology.yaml

}


create_cluster_deploy_topology_file |tee  ${scriptsLog}
