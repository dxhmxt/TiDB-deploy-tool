
#!/bin/bash
##########################
#Script name:  09_02_01_cluster_instance_user_initialize_database_variable_parameters.sh
#Script description: cluster instance user initialize database variable parameters script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
set -e
source ./mirror/cluster_base_info.conf


tidbHostName=`tiup cluster display $clusterName |awk -F" " '{print $1,$2}'|grep tidb |head -n1 |awk -F":" '{print $1}'`
tidbPort=`tiup cluster display $clusterName |awk -F" " '{print $1,$2}'|grep tidb |head -n1 |awk -F":" '{print $2}'|awk -F" " '{print $1}'`

initialize_database_variable_parameters()
{
while read line
do   
echo $line
mysql  -h$tidbHostName -P$tidbPort -u$tidbDatabaseUserRoot -p$tidbDatabaseUserRootPassword  -e"$line"
done<$dirHome/mirror/tidbinitvar.txt
echo "initialize database variable parameters is done."
echo "###############################################"
}

check_initialize_variable_parameters()
{
echo "check initialize variable parameters."
cat $dirHome/mirror/tidbinitvar.txt |awk -F"=" '{print $1}'|awk -F" " '{print $3}'>varname.log

while read line
do   
mysql  -h$tidbHostName -P$tidbPort -u$tidbDatabaseUserRoot -p$tidbDatabaseUserRootPassword  -e"select @@$line;"
echo "###next row check."
done<varname.log
}

initialize_database_variable_parameters
check_initialize_variable_parameters


