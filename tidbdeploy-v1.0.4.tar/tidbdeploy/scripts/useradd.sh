
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`







create_dirhome(){
echo "create dirhome dir."
if [[ ! -d "$dirHome" ]]; then
   mkdir -p $dirHome
   echo "$dirHome is create."
else 
   echo "$dirHome is exsit."
fi
}


instance_user_add()
{

useradd   $tidbInstanceUser -d $dirHome && echo $tidbInstanceUserPassword |passwd $tidbInstanceUser --stdin
echo "user add done."

cp /etc/skel/.bashrc $dirHome
cp /etc/skel/.bash_profile $dirHome
#echo "cp .bashrc and .bash_profile done."

chown $tidbInstanceUser:$tidbInstanceUser  $dirHome/.bashrc
chown $tidbInstanceUser:$tidbInstanceUser  $dirHome/.bash_profile
chown -R $tidbInstanceUser:$tidbInstanceUser $dirHome
#echo "grant   $tidbInstanceUser  grant to $dirHome/.bashrc  and $dirHome/.bash_profile."

}

create_dirhome
instance_user_add

