
#!/bin/bash
##########################
#Script name:  05_03_create_cluster_component_topology_file.sh
#Script description: create cluster component topology file script
#Created Date:2022/12/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
confPath="/root/tidbdeploy/conf"
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_05_03_create_cluster_component_topology_file.log"

sed -i '{'/^$/d';'/^#/d'}'    $confPath/cluster_plan.conf

rm -rf  $confPath/ip_component_yaml.txt



create_cluster_component_topology_file()
{
        for  line in `awk '{print $2}'  $confPath/cluster_plan.conf | uniq`
  do
  var=$line
  awk 'BEGIN {if ("'$var'" == "prometheus") 
                          printf "monitoring_servers:\n";
                          else  if ("'$var'" == "tispark_masters") 
                          printf "tispark_masters:\n";
                          else  if ("'$var'" == "tispark_workers") 
                          printf "tispark_workers:\n";
                          else  if ("'$var'" != "prometheus" && "'$var'" != "tispark_masters" && "'$var'" != "tispark_workers")
                          printf "'$var'_servers:\n";
  
  }
  {
##########################################pd
  if  ( "'$var'" == "pd" && $2 == "pd"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    client_port: %s\n",$3;
              printf "    peer_port: %s\n",$4;
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
    }
   else 
    printf "";}

###########################################tidb
else  if  ( "'$var'" == "tidb" && $2 == "tidb"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    status_port: %s\n",$4;
              printf "    deploy_dir: %s\n",$6;    
    }
   else 
    printf "";}

###########################################tikv  
else   if ( "'$var'" == "tikv" && $2 == "tikv") {
           printf "  - host: %s\n",$1 ;
             if ( $3 != "" && $4 != "" && $5 != "" && $6 != "")
              {
              printf "    port: %s\n",$3;
              printf "    status_port: %s\n",$4;
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
                          
                 if ( $7 != "" && $8 != "" && $9 != "" && $10 != ""  && $11 != "" )
                  {
                   printf "    config:\n";
                   printf "      server.labels:\n";
                   printf "        zone: %s\n",$7;
                   printf "        dc: %s\n",$8;
                   printf "        logic: %s\n",$9;
                   printf "        rack: %s\n",$10;
                   printf "        host: %s\n",$11;                                
                }
               else 
                    printf ""
           }
              else
                  printf "";}
###########################################drainer
else  if  ( "'$var'" == "drainer" && $2 == "drainer"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
              printf "    config:\n";
              printf "      syncer.db-type: file\n";
              printf "      syncer.to.retention-time: 2\n";
              printf "      syncer.to.read-timeout: 24h\n";       
                          
                          
    }
   else 
    printf "";}

###########################################pump
else  if  ( "'$var'" == "pump" && $2 == "pump"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
    }
   else 
    printf "";}

###########################################cdc
else  if  ( "'$var'" == "cdc" && $2 == "cdc"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
    }
   else 
    printf "";}

###########################################cdc
else  if  ( "'$var'" == "cdc" && $2 == "cdc"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
    }
   else 
    printf "";}

###########################################tiflash
else  if  ( "'$var'" == "tiflash" && $2 == "tiflash"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
    }
   else 
    printf "";}

###########################################tiflash
else  if  ( "'$var'" == "tiflash" && $2 == "tiflash"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
    }
   else 
    printf "";}

###########################################tispark_masters
else  if  ( "'$var'" == "tispark_masters" && $2 == "tispark_masters"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    web_port: %s\n",$4;        
              printf "    deploy_dir: %s\n",$6;
    }
   else 
    printf "";}

###########################################tispark_workers
else  if  ( "'$var'" == "tispark_workers" && $2 == "tispark_workers"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    web_port: %s\n",$4;        
              printf "    deploy_dir: %s\n",$6;
    }
   else 
    printf "";}

###########################################tispark_workers
else  if  ( "'$var'" == "tispark_workers" && $2 == "tispark_workers"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    web_port: %s\n",$4;        
              printf "    deploy_dir: %s\n",$6;
    }
   else 
    printf "";}

###########################################prometheus
else  if  ( "'$var'" == "prometheus" && $2 == "prometheus"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
                          
    }
   else 
    printf "";}

###########################################grafana
else  if  ( "'$var'" == "grafana" && $2 == "grafana"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    port: %s\n",$3;
              printf "    deploy_dir: %s\n",$6;
                          printf "    username: admin\n";
                          printf "    password: admin\n";                                 
                          
    }
   else 
    printf "";}

###########################################alertmanager
else  if  ( "'$var'" == "alertmanager" && $2 == "alertmanager"){
     printf "  - host: %s\n",$1;;
   if ($3 != "" && $4 != "" && $5 != "" && $6 != "")
   { 
              printf "    web_port: %s\n",$3;
              printf "    cluster_port: %s\n",$4;
              printf "    deploy_dir: %s\n",$6;
              printf "    data_dir: %s\n",$5;
                          
    }
   else 
    printf "";}



  }' $confPath/cluster_plan.conf
                                        
done                                
 
}

##20230217 add check_create_component_topology_file function 
check_create_component_topology_file()
{
cat $confPath/iplist.txt | sort  -u   >$confPath/.iplist.log
cat  $confPath/cluster_plan.conf |awk -F " " '{print $1}' |sort  -u >$confPath/.planip.log
diff  $confPath/.iplist.log   $confPath/.planip.log
if [ $? -eq 0 ];
then
	create_cluster_component_topology_file |tee $confPath/ip_component_yaml.txt
else
   echo "iplist.txt ip address and cluster_plan.conf ip address is not  consistency,please ensure consistency."
   echo "####iplist.txt ip address#########"
   cat  cat $confPath/iplist.txt
   echo "####cluster_plan.conf ip address#########"
   cat   $confPath/.planip.log
   exit

fi
}

check_create_component_topology_file
