#!/bin/bash
##########################
#Script name:  04_04_check_cluster_user_ssh_mutual_trust.sh
#Script description: check cluster user huxin script
#Created Date:2022/10/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################
scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`

scriptsLog="$logPath/${nowTime}_04_04_check_cluster_user_ssh_mutual_trust.log"
#dirHome=`su - $tidbInstanceUser -c "pwd"`


cpoy_conf_script_file(){
echo "cpoy conf script file to  $dirHome."
cp -f  $confPath/cluster_base_info.conf $dirHome  
cp -f  $scriptsPath/04_04_01_check_cluster_user_ssh.sh $dirHome
cp -f  $confPath/iplist.txt $dirHome
}

chown_conf_script_file_auth()
{
echo "chown conf and script file instance user grant."
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/cluster_base_info.conf
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/04_04_01_check_cluster_user_ssh.sh
chown $tidbInstanceUser:$tidbInstanceUser $dirHome/iplist.txt 
}


check_ssh_mutual_trust()
{
echo "check instance user $tidbInstanceUser  huxin."
su - $tidbInstanceUser -c "sh 04_04_01_check_cluster_user_ssh.sh"
}

check_cluster_user_ssh_mutual_trust()
{
cpoy_conf_script_file
chown_conf_script_file_auth
check_ssh_mutual_trust
}


check_cluster_user_ssh_mutual_trust |tee  ${scriptsLog}
