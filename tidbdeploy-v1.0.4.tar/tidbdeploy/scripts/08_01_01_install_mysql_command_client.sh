
#!/bin/bash
##########################
#Script name:  08_01_01_install_mysql_command_client.sh 
#Script description: xx script
#Created Date:2023/02/xx
#Current Release Version: 1.0.0
#Script editor: maxuetao
#Support platform: linux
#Change log:
#########################

#############################
#目录                       #
#############################
set -e

scriptsPath="/root/tidbdeploy/scripts"
confPath="/root/tidbdeploy/conf"
source $confPath/cluster_base_info.conf
logPath="/root/tidbdeploy/log"
nowTime=`date +"%Y-%m-%dT%H:%M:%S"`
scriptsLog="$logPath/${nowTime}_08_02_install_mysql_client_mariadb_root.log"
echo $tidbInstanceUser


install_mysql_command_client()
{
echo "install mysql command client 'mariadb'."
su - $tidbInstanceUser -c "sudo yum install mariadb"
}


install_mysql_command_client |tee  ${scriptsLog}
